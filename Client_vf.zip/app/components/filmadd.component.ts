/**
 * Created by sydne on 25/12/2016.
 */
import { Component } from '@angular/core';

@Component({
    selector: 'filmadd',
    template: '<filmform></filmform>'
})
export class FilmAddComponent {
    constructor() { }
}