/**
 * Created by sydne on 26/12/2016.
 */
import { Component } from '@angular/core';

@Component({
    selector: 'joue',
    template: '<personnageform></personnageform>'
})
export class JoueComponent {
    constructor() { }
}
