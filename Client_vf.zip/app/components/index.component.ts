import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'index',
    templateUrl: 'app/templates/index.component.html'
})
export class IndexComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}