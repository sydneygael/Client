/**
 * Created by sydne on 24/12/2016.
 */
import { Component } from '@angular/core';

@Component({
    selector: 'acteuradd',
    template: '<acteurform></acteurform>'
})
export class ActeurAddComponent {
    constructor() { }
}