"use strict";
var Acteur = (function () {
    function Acteur(noAct, nomAct, prenAct, dateNaiss, dateDeces) {
        this.noAct = noAct;
        this.nomAct = nomAct;
        this.prenAct = prenAct;
        this.dateNaiss = dateNaiss;
        this.dateDeces = dateDeces;
    }
    return Acteur;
}());
exports.Acteur = Acteur;
//# sourceMappingURL=acteur.js.map