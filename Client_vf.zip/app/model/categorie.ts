export class Categorie {
    codeCat: string;
    libelleCat: string;
}