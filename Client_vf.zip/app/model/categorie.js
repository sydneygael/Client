"use strict";
var Categorie = (function () {
    function Categorie() {
    }
    return Categorie;
}());
exports.Categorie = Categorie;
//# sourceMappingURL=categorie.js.map