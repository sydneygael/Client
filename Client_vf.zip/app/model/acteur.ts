export class Acteur {
    constructor (
	public noAct: number,
    public nomAct: string,
    public prenAct: string,
    public dateNaiss: Date,
    public dateDeces: Date) {}
}