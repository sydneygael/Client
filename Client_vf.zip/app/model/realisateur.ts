export class Realisateur {
    noRea: number;
    nomRea: string;
    prenRea: string;
}