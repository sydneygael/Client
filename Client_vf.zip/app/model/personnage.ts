export class Personnage {
    noFilm : number;
    noAct: number;
    nomPers : string;
}