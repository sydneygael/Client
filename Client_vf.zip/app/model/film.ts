export class Film {
  noFilm: number;
  titre: string;
  duree: number;
  dateSortie: Date;
  budget: number;
  montantRecette: number;
  noRea:number;
  codeCat:string;
}