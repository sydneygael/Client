"use strict";
var Film = (function () {
    function Film() {
    }
    return Film;
}());
exports.Film = Film;
//# sourceMappingURL=film.js.map