"use strict";
var Personnage = (function () {
    function Personnage() {
    }
    return Personnage;
}());
exports.Personnage = Personnage;
//# sourceMappingURL=personnage.js.map